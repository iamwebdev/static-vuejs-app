<template>
  <my-sidebar></my-sidebar>
  <my-body></my-body>
</template>

<script>
import SideBar from './components/Sidebar.vue'
import Body from './components/Body.vue'

export default {
  name: 'App',
  components: {
    'my-sidebar':SideBar,
    'my-body': Body
  }
}
</script>
<style>
</style>
